package entity;

import java.util.Random;

import main.Gamepanel;

public class NPC_John extends Entity {
	
	public NPC_John(Gamepanel gp) {
		super(gp);
		
		direction = "down";
		speed = 1;
		
		getImage();
		setDialouge();
	}
	public void getImage() {
	
			
			up1 = setup ("/npc/johnup1", gp.tileSize, gp.tileSize);
			up2 = setup("/npc/johnup2", gp.tileSize, gp.tileSize);
			down1 = setup("/npc/johndown1", gp.tileSize, gp.tileSize);
			down2 = setup("/npc/johndown2", gp.tileSize, gp.tileSize);
			left1 = setup("/npc/johnleft1", gp.tileSize, gp.tileSize);
			left2 =setup("/npc/johnleft2", gp.tileSize, gp.tileSize);
			right1 = setup("/npc/johnright1", gp.tileSize, gp.tileSize);
			right2 = setup("/npc/johnright2", gp.tileSize, gp.tileSize);
			
	}
	public void setDialouge() {
		dialouges[0] = "HOLY SHIT THEO?!?! IS THAT YOU?";
		dialouges[1] = "Dude I thought you were dead";
		dialouges[2] = "Have you seen my phone? I need to watch a few tiktoks";
		dialouges[3] = "no? FUCK!!!!!!";
		dialouges[4] = "Please dude just get me the fuck out of here \n I keep hearing screaming it sounds like a monster";
		dialouges[5] = "All night I heard 'JIMMY!!!! YOU ARE A FAT HOG!' Over and over again!.\n It sounda alot like Nick but I can't tell for sure I don't even have my dab rig \nto mellow me out";
		dialouges[6] = "All I've got is this joint i stole off Mike before the bar. I could'nt help it, \nit was the fellon in me, but it's not even calming me down though. \n Joints are below me but I have nothing else.";

				
	}
	public void setAction() {
		actionLockCounter ++;
		
		if(actionLockCounter == 120) {
			Random random = new Random();
			int i = random.nextInt(100)+1; 
			
			if (i <= 30) {
			    direction = "up";
			} else if (i > 30 && i <= 50) {
			    direction = "down";
			} else if (i > 50 && i <= 80) {
			    direction = "left";
			} else if (i > 80 && i <= 100) {
			    direction = "right";
			}

			
			actionLockCounter = 0;
			
		}
		
		
	}
	public void speak() {
		
		//does charater stuff
		gp.ui.currentDialouge = dialouges[0];
		super.speak();
	}
}
	



