package entity;

import java.util.Random;

import main.Gamepanel;
import object.OBJ_Beer;
import object.OBJ_Dildo_Sword;
import object.OBJ_Jimmysass;
import object.OBJ_Spicyburger;

public class NPC_Josh extends Entity {
	
	public NPC_Josh(Gamepanel gp) {
	    super(gp);
	    setDialouge();
	    setItems();
	    
	

		
		
		direction = "down";
		speed = 1;
		
		getImage();
	}
	public void getImage() {
	
			
			up1 = setup ("/npc/joshup1", gp.tileSize, gp.tileSize);
			up2 = setup("/npc/joshup2", gp.tileSize, gp.tileSize);
			down1 = setup("/npc/joshdown1", gp.tileSize, gp.tileSize);
			down2 = setup("/npc/joshdown2", gp.tileSize, gp.tileSize);
			left1 = setup("/npc/joshleft1", gp.tileSize, gp.tileSize);
			left2 =setup("/npc/joshleft2", gp.tileSize, gp.tileSize);
			right1 = setup("/npc/joshright1", gp.tileSize, gp.tileSize);
			right2 = setup("/npc/joshright2", gp.tileSize, gp.tileSize);
	}
			public void setDialouge() {
				dialouges[0] = "IM NO SURE WHO I LOVE MORE, JESUS OR BRIA...\nOh hey there! Im assuming your here for conversion?\nI have some stuff you might want to buy.\nAll proceeds go to the 'Talks with Brian Outside Foundation'";
			
				
						
			}
			
			public void setItems() {
				
				inventory.add(new OBJ_Beer(gp));
				inventory.add(new OBJ_Jimmysass(gp));
				inventory.add(new OBJ_Spicyburger(gp));
				inventory.add(new OBJ_Dildo_Sword(gp));			}
		
			public void setAction() {
				actionLockCounter ++;
				
				if(actionLockCounter == 120) {
					Random random = new Random();
					int i = random.nextInt(100)+1; 
					
					if (i <= 30) {
					    direction = "up";
					} else if (i > 30 && i <= 50) {
					    direction = "down";
					} else if (i > 50 && i <= 80) {
					    direction = "left";
					} else if (i > 80 && i <= 100) {
					    direction = "right";
					}

					
					actionLockCounter = 0;
					
				}
				
				
			}
			public void speak() {
				gp.ui.currentDialouge = dialouges[0];
				
				super.speak();
				gp.gameState = gp.tradeState;
				gp.ui.npc = this;
				
				
			}

}
