package monster;

import java.util.Random;

import entity.Entity;
import main.Gamepanel;
import object.OBJ_Cheese;

public class MON_Armored_Tuchi extends Entity {
Gamepanel gp;
	public MON_Armored_Tuchi(Gamepanel gp) {
		super(gp);
		this.gp = gp;
		type = type_monster;
		name = " an Armored Tuchi";
		speed = 5;
		maxLife = 6;
		life = maxLife;
		attack = 7;
		defense = 5;
		exp = 20;
		projectile = new OBJ_Cheese(gp);
		
		solidArea.x = 3;
		solidArea.y = 18;
		solidArea.width = 42;
		solidArea.height = 30;
		solidAreaDefaultX = solidArea.x;
		solidAreaDefaultY = solidArea.y;
		
		getImage();
		}
public void getImage() {
	
	up1 = setup("/monster/armorrat1", gp.tileSize, gp.tileSize);
	up2 = setup("/monster/armorrat2", gp.tileSize, gp.tileSize);
	down1 = setup("/monster/armorrat1", gp.tileSize, gp.tileSize);
	down2 = setup("/monster/armorrat2", gp.tileSize, gp.tileSize);
	left1 = setup("/monster/armorrat1", gp.tileSize, gp.tileSize);
	left2 = setup("/monster/armorrat2", gp.tileSize, gp.tileSize);
	right1 = setup("/monster/armorrat1", gp.tileSize, gp.tileSize);
	right2 = setup("/monster/armorrat2", gp.tileSize, gp.tileSize);
	
}
public void setAction() {
	
		actionLockCounter ++;
		
		if(actionLockCounter == 120) {
			Random random = new Random();
			int i = random.nextInt(100)+1; 
			
			if (i <= 30) {
			    direction = "up";
			} else if (i > 30 && i <= 50) {
			    direction = "down";
			} else if (i > 50 && i <= 80) {
			    direction = "left";
			} else if (i > 80 && i <= 100) {
			    direction = "right";
			}

			
			actionLockCounter = 0;
						
			
		}
		
		
		int i = new Random().nextInt(100) +1;
		if(i> 99 && projectile.alive == false && shotAvailableCounter == 30) {
			
			projectile.set(worldX,  worldY,  direction,  true,  this);
			gp.projectileList.add(projectile);
			shotAvailableCounter = 0;
			
		}
}

public void damageReaction() {
	actionLockCounter = 0;
	direction = gp.player.direction;
	
}


}
