package main;

import entity.NPC_Ian;
import entity.NPC_John;
import entity.NPC_Josh;
import entity.NPC_Liam;
import entity.NPC_Mike;
import entity.NPC_Miles;
import entity.NPC_Vic;
import monster.MON_Armored_Tuchi;
import monster.MON_Kunt_Krab;
import monster.MON_Nick;
import monster.MON_Tuchi;
import object.OBJ_Beer;
import object.OBJ_Boxcutter;
import object.OBJ_Burger;
import object.OBJ_Chest;
import object.OBJ_Dildo_Sword;
import object.OBJ_Door;
import object.OBJ_Fart_Coin;
import object.OBJ_Jimmysass;
import object.OBJ_Key;
import object.OBJ_Pest;
import object.OBJ_Rattail;
import object.OBJ_Spicyburger;


public class AssetSetter {
	
	Gamepanel gp;
	
	public AssetSetter(Gamepanel gp) {
		this.gp = gp;
	}
	
	public void setObject() {
		int mapNum = 0;
		int i = 0;
		//gp.obj[mapNum][0] = new OBJ_Door(gp);
		//gp.obj[mapNum][0].worldX = gp.tileSize*23;
		//gp.obj[mapNum][0].worldY = gp.tileSize*32;
		
		//gp.obj[mapNum][i] = new OBJ_Key(gp);
		//gp.obj[mapNum][i].worldX = gp.tileSize*25;
		//gp.obj[mapNum][i].worldY = gp.tileSize*22;
		//i++;
		
		gp.obj[mapNum][i] = new OBJ_Key(gp);
		gp.obj[mapNum][i].worldX = gp.tileSize*25;
		gp.obj[mapNum][i].worldY = gp.tileSize*22;
		i++;
		
		
		
		gp.obj[mapNum][i] = new OBJ_Fart_Coin(gp);
		gp.obj[mapNum][i].worldX = gp.tileSize*24;
		gp.obj[mapNum][i].worldY = gp.tileSize*20;
		i++;
		
		gp.obj[mapNum][i] = new OBJ_Key(gp);
		gp.obj[mapNum][i].worldX = gp.tileSize*10;
		gp.obj[mapNum][i].worldY = gp.tileSize*1;
		i++;
		
		gp.obj[mapNum][i] = new OBJ_Boxcutter(gp);
		gp.obj[mapNum][i].worldX = gp.tileSize*12;
		gp.obj[mapNum][i].worldY = gp.tileSize*22;
		i++;
		
		
		
		gp.obj[mapNum][i] = new OBJ_Spicyburger(gp);
		gp.obj[mapNum][i].worldX = gp.tileSize*1;
		gp.obj[mapNum][i].worldY = gp.tileSize*34;
		i++;
		
		
		gp.obj[mapNum][i] = new OBJ_Rattail(gp);
		gp.obj[mapNum][i].worldX = gp.tileSize*13;
		gp.obj[mapNum][i].worldY = gp.tileSize*39;
		i++;
		
		gp.obj[mapNum][i] = new OBJ_Rattail(gp);
		gp.obj[mapNum][i].worldX = gp.tileSize*35;
		gp.obj[mapNum][i].worldY = gp.tileSize*45;
		i++;
		
		gp.obj[mapNum][i] = new OBJ_Rattail(gp);
		gp.obj[mapNum][i].worldX = gp.tileSize*42;
		gp.obj[mapNum][i].worldY = gp.tileSize*23;
		i++;
		
		gp.obj[mapNum][i] = new OBJ_Rattail(gp);
		gp.obj[mapNum][i].worldX = gp.tileSize*34;
		gp.obj[mapNum][i].worldY = gp.tileSize*16;
		i++;
		
		gp.obj[mapNum][i] = new OBJ_Rattail(gp);
		gp.obj[mapNum][i].worldX = gp.tileSize*13;
		gp.obj[mapNum][i].worldY = gp.tileSize*18;
		i++;
		
		gp.obj[mapNum][i] = new OBJ_Rattail(gp);
		gp.obj[mapNum][i].worldX = gp.tileSize*42;
		gp.obj[mapNum][i].worldY = gp.tileSize*14;
		i++;
		
		
		gp.obj[mapNum][i] = new OBJ_Beer(gp);
		gp.obj[mapNum][i].worldX = gp.tileSize*7;
		gp.obj[mapNum][i].worldY = gp.tileSize*1;
		i++;
		
		gp.obj[mapNum][i] = new OBJ_Beer(gp);
		gp.obj[mapNum][i].worldX = gp.tileSize*43;
		gp.obj[mapNum][i].worldY = gp.tileSize*22;
		i++;
		
		gp.obj[mapNum][i] = new OBJ_Beer(gp);
		gp.obj[mapNum][i].worldX = gp.tileSize*1;
		gp.obj[mapNum][i].worldY = gp.tileSize*46;
		i++;
		
		gp.obj[mapNum][i] = new OBJ_Beer(gp);
		gp.obj[mapNum][i].worldX = gp.tileSize*1;
		gp.obj[mapNum][i].worldY = gp.tileSize*43;
		i++;
		
		gp.obj[mapNum][i] = new OBJ_Beer(gp);
		gp.obj[mapNum][i].worldX = gp.tileSize*17;
		gp.obj[mapNum][i].worldY = gp.tileSize*4;
		i++;
		
		///gp.obj[mapNum][i] = new OBJ_Door(gp);
		///gp.obj[mapNum][i].worldX = gp.tileSize*38;
		///gp.obj[mapNum][i].worldY = gp.tileSize*11;
		
		///gp.obj[mapNum][i] = new OBJ_Door(gp);
		//gp.obj[mapNum][i].worldX = gp.tileSize*16;
		//gp.obj[mapNum][i].worldY = gp.tileSize*8;
		
	      mapNum = 1;
	      
	      gp.obj[mapNum][i] = new OBJ_Jimmysass(gp);
			gp.obj[mapNum][i].worldX = gp.tileSize*10;
			gp.obj[mapNum][i].worldY = gp.tileSize*35;
			i++;
		
	
				
	}
	public void setNPC() {
		int i = 0;
		int mapNum = 0;
		gp.npc[mapNum][i] = new NPC_Ian(gp);
		gp.npc[mapNum][i].worldX = gp.tileSize*17;
		gp.npc[mapNum][i].worldY = gp.tileSize*6;
		i++;
		
		gp.npc[mapNum][i] = new NPC_Vic(gp);
		gp.npc[mapNum][i].worldX = gp.tileSize*22;
		gp.npc[mapNum][i].worldY = gp.tileSize*22;
		i++;
		
		gp.npc[mapNum][i] = new NPC_Liam(gp);
		gp.npc[mapNum][i].worldX = gp.tileSize*30;
		gp.npc[mapNum][i].worldY = gp.tileSize*45;
		i++;
		
		gp.npc[mapNum][i] = new NPC_Miles(gp);
		gp.npc[mapNum][i].worldX = gp.tileSize*38;
		gp.npc[mapNum][i].worldY = gp.tileSize*4;
		i++;
		
		gp.npc[mapNum][i] = new NPC_Mike(gp);
		gp.npc[mapNum][i].worldX = gp.tileSize*3;
		gp.npc[mapNum][i].worldY = gp.tileSize*34;
		i++;
		
		gp.npc[mapNum][i] = new NPC_Josh(gp);
		gp.npc[mapNum][i].worldX = gp.tileSize*22;
		gp.npc[mapNum][i].worldY = gp.tileSize*30;
		i++;
		
		mapNum = 1;
		
		gp.npc[mapNum][i] = new NPC_John(gp);
		gp.npc[mapNum][i].worldX = gp.tileSize*3;
		gp.npc[mapNum][i].worldY = gp.tileSize*34;
		i++;
		
		gp.npc[mapNum][i] = new NPC_Josh(gp);
		gp.npc[mapNum][i].worldX = gp.tileSize*10;
		gp.npc[mapNum][i].worldY = gp.tileSize*35;
		i++;
		
	}
	public void setMonster() {
		int mapNum = 0;
		int i = 0;
		
		gp.monster[mapNum][i] = new MON_Tuchi(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize*5;
		gp.monster[mapNum][i].worldY = gp.tileSize*35;	
		i++;
		
		gp.monster[mapNum][i] = new MON_Tuchi(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize*13;
		gp.monster[mapNum][i].worldY = gp.tileSize*22;	
		i++;
		
		gp.monster[mapNum][i] = new MON_Tuchi(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize*13;
		gp.monster[mapNum][i].worldY = gp.tileSize*21;
		i++;
		
		gp.monster[mapNum][i] = new MON_Tuchi(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize*5;
		gp.monster[mapNum][i].worldY = gp.tileSize*30;
		i++;
		
		gp.monster[mapNum][i] = new MON_Tuchi(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize*28;
		gp.monster[mapNum][i].worldY = gp.tileSize*45;
		i++;
		
		gp.monster[mapNum][i] = new MON_Armored_Tuchi(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize*43;
		gp.monster[mapNum][i].worldY = gp.tileSize*15;
		i++;
		
		gp.monster[mapNum][i] = new MON_Armored_Tuchi(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize*48;
		gp.monster[mapNum][i].worldY = gp.tileSize*2;
		i++;
		
		gp.monster[mapNum][i] = new MON_Armored_Tuchi(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize*31;
		gp.monster[mapNum][i].worldY = gp.tileSize*1;
		i++;
		
		gp.monster[mapNum][i] = new MON_Armored_Tuchi(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize*44;
		gp.monster[mapNum][i].worldY = gp.tileSize*15;
		i++;
		
		gp.monster[mapNum][i] = new MON_Kunt_Krab(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize*6;
		gp.monster[mapNum][i].worldY = gp.tileSize*43;
		i++;
		
		gp.monster[mapNum][i] = new MON_Kunt_Krab(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize*6;
		gp.monster[mapNum][i].worldY = gp.tileSize*45;
		i++;
		
		gp.monster[mapNum][i] = new MON_Kunt_Krab(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize*48;
		gp.monster[mapNum][i].worldY = gp.tileSize*46;
		i++;
		
		gp.monster[mapNum][i] = new MON_Kunt_Krab(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize*48;
		gp.monster[mapNum][i].worldY = gp.tileSize*44;
		i++;
		
		
		
		gp.monster[mapNum][i] = new MON_Tuchi(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize*42;
		gp.monster[mapNum][i].worldY = gp.tileSize*15;
		i++;
		
		gp.monster[mapNum][i] = new MON_Tuchi(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize*1;
		gp.monster[mapNum][i].worldY = gp.tileSize*3;
		i++;
		
		gp.monster[mapNum][i] = new MON_Tuchi(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize*6;
		gp.monster[mapNum][i].worldY = gp.tileSize*5;
		i++;
		
		gp.monster[mapNum][i] = new MON_Kunt_Krab(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize*45;
		gp.monster[mapNum][i].worldY = gp.tileSize*44;
		i++;
		
		gp.monster[mapNum][i] = new MON_Tuchi(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize*20;
		gp.monster[mapNum][i].worldY = gp.tileSize*15;
		i++;
		
		gp.monster[mapNum][i] = new MON_Tuchi(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize*20;
		gp.monster[mapNum][i].worldY = gp.tileSize*11;
		i++;
		
		mapNum = 1;
		
		gp.monster[mapNum][i] = new MON_Armored_Tuchi(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize*48;
		gp.monster[mapNum][i].worldY = gp.tileSize*2;
		i++;
		
		gp.monster[mapNum][i] = new MON_Nick(gp);
		gp.monster[mapNum][i].worldX = gp.tileSize*46;
		gp.monster[mapNum][i].worldY = gp.tileSize*36;
		i++;
		
		
		
		
		
	}
	
	
}
	
	
