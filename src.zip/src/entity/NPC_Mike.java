package entity;

import java.util.Random;

import main.Gamepanel;

public class NPC_Mike extends Entity{

	public NPC_Mike(Gamepanel gp) {
		super(gp);
		
		direction = "down";
		speed = 1;
		
		getImage();
		setDialouge();
	}
	public void getImage() {
	
			
			up1 = setup ("/npc/mikedown1", gp.tileSize, gp.tileSize);
			up2 = setup("/npc/mikedown2", gp.tileSize, gp.tileSize);
			down1 = setup("/npc/mikedown1", gp.tileSize, gp.tileSize);
			down2 = setup("/npc/mikedown2", gp.tileSize, gp.tileSize);
			left1 = setup("/npc/mikedown1", gp.tileSize, gp.tileSize);
			left2 =setup("/npc/mikedown2", gp.tileSize, gp.tileSize);
			right1 = setup("/npc/mikedown1", gp.tileSize, gp.tileSize);
			right2 = setup("/npc/mikedown2", gp.tileSize, gp.tileSize);
			
	}
	public void setDialouge() {
		dialouges[0] = "Oh daddy *smooch*";
	
	}
	public void setAction() {
		actionLockCounter ++;
		
		if(actionLockCounter == 120) {
			Random random = new Random();
			int i = random.nextInt(100)+1; 
			
			if (i <= 30) {
			    direction = "up";
			} else if (i > 30 && i <= 50) {
			    direction = "down";
			} else if (i > 50 && i <= 80) {
			    direction = "left";
			} else if (i > 80 && i <= 100) {
			    direction = "right";
			}

			
			actionLockCounter = 0;
			
		}
		
		
	}
	public void speak() {
		
		//does charater stuff
		gp.ui.currentDialouge = dialouges[0];
		super.speak();
	}

	}


