package entity;

import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;

import main.Gamepanel;

public class NPC_Vic extends Entity {
	
	public NPC_Vic(Gamepanel gp) {
		super(gp);
		
		direction = "down";
		speed = 1;
		
		getImage();
		setDialouge();
	}
	public void getImage() {
	
			
			up1 = setup ("/npc/vicup1", gp.tileSize, gp.tileSize);
			up2 = setup("/npc/vicup2", gp.tileSize, gp.tileSize);
			down1 = setup("/npc/vicdown1", gp.tileSize, gp.tileSize);
			down2 = setup("/npc/vicdown2", gp.tileSize, gp.tileSize);
			left1 = setup("/npc/vicleft1", gp.tileSize, gp.tileSize);
			left2 =setup("/npc/vicleft2", gp.tileSize, gp.tileSize);
			right1 = setup("/npc/vicright1", gp.tileSize, gp.tileSize);
			right2 = setup("/npc/vicright2", gp.tileSize, gp.tileSize);
			
	}
	public void setDialouge() {
		dialouges[0] = "Finally, your dumbass is awake.";
		dialouges[1] = "We must have blacked out on our way home from \nthe bar!.";
		dialouges[2] = "Black... EW!";
		dialouges[3] = "I TOLD YOU WE SHOULD HAVE GONE HOME AFTER MAGIC!! BUT \nNOOO FATTY HAD TO GET ALCHY!!!";
		dialouges[4] = "...When I woke up I saw this rat-like creature \nclosing the door down the hallway";
		dialouges[5] = " I think it was trying to lock us in here, but \nthe inbread fuck forgot to take the key with em";
		dialouges[6] = "Grab the key and unlock the door \nYOU BOX HEADED FUCK!!!";
		dialouges[7] = "I would have done it but I'm too tired. I havent \nhad a white monster in over an hour! ";
		dialouges[8] = "Oh wait! don't you still have that rat spray on you? \nTry using that on those rat-things if you run into them!";
		dialouges[9] = "Press ENTER when those mother fuckers get in your face. \nThat should fuck em up.";
		dialouges[10] = "For once you're square ass was right about bringing it to the \nshop.";
	}
	public void setAction() {
		actionLockCounter ++;
		
		if(actionLockCounter == 60) {
			Random random = new Random();
			int i = random.nextInt(100)+1; 
			
			if (i <= 30) {
			    direction = "up";
			} else if (i > 30 && i <= 50) {
			    direction = "down";
			} else if (i > 50 && i <= 80) {
			    direction = "left";
			} else if (i > 80 && i <= 100) {
			    direction = "right";
			}

			
			actionLockCounter = 0;
			
		}
		
	
		
	}
	public void speak() {
		super.speak();
	}
}
	