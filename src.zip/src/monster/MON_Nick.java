package monster;

import java.util.Random;

import entity.Entity;
import main.Gamepanel;
import object.OBJ_Dildo_Sword;
import object.OBJ_Fart_Coin;
import object.OBJ_Rattail;

public class MON_Nick extends Entity{
	

	Gamepanel gp;
	public MON_Nick(Gamepanel gp) {
		super(gp);
		this.gp = gp;
		type = type_monster;
		name = "a Tuchi";
		speed = 2;
		maxLife = 10;
		life = maxLife;
		attack = 7;
		defense = 6;
		exp = 50;
		
		solidArea.x = 3;
		solidArea.y = 18;
		solidArea.width = 42;
		solidArea.height = 30;
		solidAreaDefaultX = solidArea.x;
		solidAreaDefaultY = solidArea.y;
		
		getImage();
		}
public void getImage() {
	
	up1 = setup("/monster/nickdown1", gp.tileSize, gp.tileSize);
	up2 = setup("/monster/nickdown2", gp.tileSize, gp.tileSize);
	down1 = setup("/monster/nickdown1", gp.tileSize, gp.tileSize);
	down2 = setup("/monster/nickdown2", gp.tileSize, gp.tileSize);
	left1 = setup("/monster/nickdown1", gp.tileSize, gp.tileSize);
	left2 = setup("/monster/nickdown2", gp.tileSize, gp.tileSize);
	right1 = setup("/monster/nickdown1", gp.tileSize, gp.tileSize);
	right2 = setup("/monster/nickdown2", gp.tileSize, gp.tileSize);
	
}
public void setAction() {
	
		actionLockCounter ++;
		
		if(actionLockCounter == 120) {
			Random random = new Random();
			int i = random.nextInt(100)+1; 
			
			if (i <= 30) {
			    direction = "up";
			} else if (i > 30 && i <= 50) {
			    direction = "down";
			} else if (i > 50 && i <= 80) {
			    direction = "left";
			} else if (i > 80 && i <= 100) {
			    direction = "right";
			}

			
			actionLockCounter = 0;
			
		}
}
public void damageReaction() {
	actionLockCounter = 0;
	direction = gp.player.direction;
	
}
public void checkDrop() {
	//CAST A DICE
	int i = new Random().nextInt (100)+1;
	
	// SETS THE MONSTER DROP
	if(i < 50) {
		dropItem(new OBJ_Fart_Coin (gp));
	}
	if (i >= 0 && i < 5) {
	    dropItem(new OBJ_Dildo_Sword(gp));
	}
	if( i >= 75  && i < 100) {
		dropItem (new OBJ_Rattail(gp));
	}
}


}


